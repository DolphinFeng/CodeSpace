# element-ui

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

----------------------------------------------------------------

# cli脚手架

安装：

任意终端输入指令：npm i -g @vue/cli

vue --version可以看到版本号就代表安装成功

选中第三个Manual



----------------------------------------------------------------

.browserslistrc  这个文件是浏览器版本，兼容性问题。可要可不要

.gitignore cli这个脚手架帮你把module过滤了

babel.config 这里可以配置需要什么不需要什么

jsconfig cli中配置文件，es6文件最终会被转成es5  相当于项目说明书
    敲了@一定就是src下的文件

package-lock 记录

vue.config vue配置

less标签的语法是嵌套的



环境分为：开发环境，生产环境
npm install element-plus --save
--save是生产环境： 能带来生产力