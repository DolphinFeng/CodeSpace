<template>
    <div class="home_container">
        <item-container parent-component="home"></item-container>
    </div>
</template>

<script>
import ItemContainer from '@/components/ItemContainer.vue'
    export default {
        components: {
            ItemContainer
        }
    }
</script>

<style lang="less" scoped>

</style>