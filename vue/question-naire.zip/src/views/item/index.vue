<template>
    <div>
        item
        <ItemContainer parent-component="item"/>
    </div>
</template>

<script>
import ItemContainer from '@/components/ItemContainer.vue'
    export default {
        components: {
            ItemContainer
        }
    }
</script>

<style lang="less" scoped>

</style>